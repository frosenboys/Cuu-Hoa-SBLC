package com.sblc.controller;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

@SuppressLint("ClickableViewAccessibility")
public class ControlActivity extends AppCompatActivity
{
    Button btnDis,btnPhun,btnForward, btnBackward,  btnLeft, btnRight;
    private MainActivity mainActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.control_activity);
        mainActivity = (MainActivity) getIntent().getSerializableExtra("MainActivity");

        btnForward = findViewById(R.id.up_btn);
        btnBackward = findViewById(R.id.down_btn);
        btnLeft = findViewById(R.id.left_btn);
        btnRight = findViewById(R.id.right_btn);
        btnDis = findViewById(R.id.connect);
        btnPhun = findViewById(R.id.fire);
        
        btnForward.setOnTouchListener((v, event) -> {
            switch (event.getAction())
            {
                   case MotionEvent.ACTION_DOWN: run("u"); break;
                    case MotionEvent.ACTION_UP: run("s"); break;
            }

            return true;
        });
        btnBackward.setOnTouchListener((v, event) -> {
            switch (event.getAction())
            {
                    case MotionEvent.ACTION_DOWN: run("d"); break;
                    case MotionEvent.ACTION_UP: run("s"); break;
            }

            return true;
        });
        
        btnLeft.setOnTouchListener((v, event) -> {
            switch (event.getAction())
            {
                    case MotionEvent.ACTION_DOWN: run("l"); break;
                    case MotionEvent.ACTION_UP: stop("b"); break;
            }

            return true;
        });
        
        btnRight.setOnTouchListener((v, event) -> {
            switch (event.getAction())
            {
                    case MotionEvent.ACTION_DOWN: run("r"); break;
                    case MotionEvent.ACTION_UP: stop("b"); break;
            }

            return true;
        });
        

        btnPhun.setOnTouchListener((v, event) -> {
            switch (event.getAction())
            {
                    case MotionEvent.ACTION_DOWN: run("p"); break;
                    case MotionEvent.ACTION_UP: stop("k"); break;
            }

            return true;
        });

        btnDis.setOnTouchListener((v, event) -> {
            Disconnect();
            return true;
        });
    }

    private void run(String s) {
        MainActivity.ct.write(s.getBytes());
     }
    private void stop(String s)
    {
        MainActivity.ct.write(s.getBytes());
    }
    private void Disconnect()
    {
        MainActivity.ct.cancel();
        finish();
        System.exit(0);
    }

}
